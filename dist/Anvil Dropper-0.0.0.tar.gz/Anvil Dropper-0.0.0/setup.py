import cx_Freeze
executeables = [cx_Freeze.Executable("game.py")]
cx_Freeze.setup(
    name="Anvil Dropper",
    options ={
        "build_exe":{
            "packages":["pygame"],
            "include_files":[
                "./assets/Anton-Regular.ttf",
                "./assets/anvil.png",
                "./assets/Balloon Game.mp3",
                "./assets/blue.png",
                "./assets/gameBg.png",
                "./assets/menuWallpaper.png"
                ]
        }
    },
    executeables = executeables
)